# SOURCE MANIFEST

## Included Files:
- `[FOUND]` ml-service/main.py 
- `[FOUND]` ml-service/Dockerfile 
- `[FOUND]` ml-service/requirements.txt 
- `[FOUND]` ml-service/compare_weights.py (local import script)
- `[FOUND]` ml-service/custom_loader.py (local import script)
- `[FOUND]` ml-service/debug_keras.py (local import script)
- `[FOUND]` ml-service/debug_keras2.py (local import script)
- `[FOUND]` ml-service/debug_transpose.py (local import script)
- `[FOUND]` ml-service/debug_weights.py (local import script)
- `[FOUND]` ml-service/inspect_h5.py (local import script)
- `[FOUND]` ml-service/print_decoder.py (local import script)
- `[FOUND]` ml-service/print_dense.py (local import script)
- `[FOUND]` ml-service/print_h5.py (local import script)
- `[FOUND]` backend/src/queues/inference.worker.ts 
- `[FOUND]` backend/src/queues/index.ts 
- `[FOUND]` backend/src/modules/inference/ 
- `[FOUND]` backend/src/modules/watchlist/ 
- `[FOUND]` backend/src/sockets/ 
- `[FOUND]` backend/src/config/minio.ts 
- `[FOUND]` backend/prisma/schema.prisma 
- `[FOUND]` backend/prisma/migrations/ 
- `[FOUND]` backend/docker-compose.yml 
- `[FOUND]` backend/.env.example 
- `[FOUND]` backend/mediamtx.yml 
- `[FOUND]` disguise-raps/v2/disguiseid_capture.py 
- `[FOUND]` disguise-raps/v2/test_kirim.py (local import script)
- `[FOUND]` frontend/services/socket.ts 
- `[FOUND]` frontend/store/alertStore.ts 
- `[FOUND]` frontend/services/ 

## Not Found / Excluded Files:
- `[NOT FOUND / EXCLUDED]` frontend/components/alerts/
- `[NOT FOUND / EXCLUDED]` frontend/app/alerts/
- `[NOT FOUND / EXCLUDED]` frontend/app/live/
