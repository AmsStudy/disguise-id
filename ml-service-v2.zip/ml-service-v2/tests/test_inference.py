import pytest
import numpy as np
from app.services.inference_service import InferenceService
from app.schemas import BranchResult
from app.config import settings

class DummyInferenceService(InferenceService):
    def __init__(self):
        pass

def test_margin_max_original_better():
    svc = DummyInferenceService()
    orig = BranchResult(valid=True, candidate_id="A", score=0.9, margin=0.5)
    recon = BranchResult(valid=True, candidate_id="B", score=0.8, margin=0.4)
    sel = svc._choose_margin_max(orig, recon)
    assert sel["selected_branch"] == "original"

def test_margin_max_reconstructed_better():
    svc = DummyInferenceService()
    orig = BranchResult(valid=True, candidate_id="A", score=0.8, margin=0.4)
    recon = BranchResult(valid=True, candidate_id="B", score=0.9, margin=0.5)
    sel = svc._choose_margin_max(orig, recon)
    assert sel["selected_branch"] == "reconstructed"

def test_margin_max_fallback_invalid_recon():
    svc = DummyInferenceService()
    orig = BranchResult(valid=True, candidate_id="A", score=0.8, margin=0.4)
    recon = BranchResult(valid=False)
    sel = svc._choose_margin_max(orig, recon)
    assert sel["selected_branch"] == "original"

def test_decision_policy_high():
    svc = DummyInferenceService()
    decision = svc._make_decision("A", settings.high_threshold + 0.1, settings.margin_threshold + 0.1)
    assert decision == "HIGH_PRIORITY_CANDIDATE"

def test_decision_policy_possible():
    svc = DummyInferenceService()
    decision = svc._make_decision("A", settings.possible_threshold + 0.05, 0.01)
    assert decision == "POSSIBLE_MATCH"

def test_decision_policy_unknown():
    svc = DummyInferenceService()
    decision = svc._make_decision("A", 0.1, 0.1)
    assert decision == "UNKNOWN"

def test_decision_policy_no_face():
    svc = DummyInferenceService()
    decision = svc._make_decision(None, float('nan'), float('nan'))
    assert decision == "NO_VALID_FACE"
