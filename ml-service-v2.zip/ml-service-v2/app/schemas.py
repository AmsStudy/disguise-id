from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any

class BranchResult(BaseModel):
    valid: bool
    candidate_id: Optional[str]
    score: float = float('nan')
    second_score: float = float('nan')
    margin: float = float('nan')
    detection_score: Optional[float] = None
    reconstruction_ms: Optional[float] = None
    error: Optional[str] = None

class InferenceResponse(BaseModel):
    request_id: str
    organization_id: str
    camera_id: str
    camera_session_id: str
    track_id: str
    model_version: str
    gallery_version: str
    original: BranchResult
    reconstructed: BranchResult
    selected_branch: Optional[str]
    candidate_id: Optional[str]
    score: float = float('nan')
    margin: float = float('nan')
    frame_decision: str
    processing_ms: float
    requires_operator_verification: bool
