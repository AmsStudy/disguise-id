import os
import sys
import argparse
from pathlib import Path
import subprocess
import time
import httpx
import pandas as pd
import json

def run_stage36_script(project_dir: Path, gallery_csv: Path, input_dir: Path, output_dir: Path):
    script_path = project_dir / "scripts" / "36_margin_max_terminal_decision_engine.py"
    if not script_path.exists():
        raise FileNotFoundError(f"Original Stage 36 script not found: {script_path}")
        
    cmd = [
        sys.executable,
        str(script_path),
        "--project-dir", str(project_dir),
        "--gallery-csv", str(gallery_csv),
        "--input", str(input_dir),
        "--output", str(output_dir),
        "--save-images"
    ]
    
    print("Running original Stage 36 script for baseline generation...")
    subprocess.run(cmd, check=True)
    print("Baseline generated.")

def compare_results(baseline_csv: Path, api_url: str, api_key: str, input_dir: Path, output_dir: Path):
    df = pd.read_csv(baseline_csv)
    
    # Sort files just like the script does
    images = sorted([p for p in input_dir.rglob("*") if p.is_file() and p.suffix.lower() in {".jpg", ".jpeg", ".png", ".bmp", ".webp", ".tif", ".tiff"}], key=lambda x: str(x).lower())
    
    if len(images) != len(df):
        raise ValueError("Number of input images does not match number of baseline results.")
        
    failures = []
    
    print("Sending requests to V2 API and comparing...")
    for idx, (img_path, row) in enumerate(zip(images, df.itertuples())):
        files = {"face_crop": (img_path.name, open(img_path, "rb"), "image/jpeg")}
        data = {
            "organization_id": "test_org",
            "camera_id": "test_cam",
            "camera_session_id": "test_session",
            "track_id": f"test_track_{idx}",
            "captured_at": "2026-08-04T07:26:10Z",
            "frame_number": idx,
            "bounding_box_json": "[0,0,100,100]"
        }
        
        headers = {"x-api-key": api_key}
        
        try:
            resp = httpx.post(api_url, files=files, data=data, headers=headers, timeout=30.0)
            resp.raise_for_status()
        except Exception as e:
            failures.append({"filename": img_path.name, "error": f"API request failed: {str(e)}"})
            continue
            
        api_res = resp.json()
        
        # Comparison logic
        errors = []
        
        # Helper for float comparison handling NaNs
        def floats_close(a, b, tol=1e-5):
            import math
            if pd.isna(a) and pd.isna(b) or math.isnan(a) and math.isnan(b):
                return True
            if pd.isna(a) or math.isnan(a) or pd.isna(b) or math.isnan(b):
                return False
            return abs(a - b) <= tol
            
        def check(field_name, baseline_val, api_val, is_float=False):
            if is_float:
                if not floats_close(baseline_val, api_val):
                    errors.append(f"{field_name} mismatch: baseline={baseline_val}, api={api_val}")
            else:
                # Handle None/NaN for strings
                b_str = "" if pd.isna(baseline_val) or baseline_val is None else str(baseline_val)
                a_str = "" if api_val is None else str(api_val)
                if b_str != a_str:
                    errors.append(f"{field_name} mismatch: baseline={b_str}, api={a_str}")

        check("original_identity", row.original_identity, api_res["original"]["candidate_id"])
        check("original_score", row.original_score, api_res["original"]["score"], is_float=True)
        check("original_margin", row.original_margin, api_res["original"]["margin"], is_float=True)
        
        check("reconstructed_identity", row.reconstructed_identity, api_res["reconstructed"]["candidate_id"])
        check("reconstructed_score", row.reconstructed_score, api_res["reconstructed"]["score"], is_float=True)
        check("reconstructed_margin", row.reconstructed_margin, api_res["reconstructed"]["margin"], is_float=True)
        
        check("selected_branch", row.selected_branch, api_res["selected_branch"])
        check("selected_identity", row.selected_identity, api_res["candidate_id"])
        check("selected_score", row.selected_score, api_res["score"], is_float=True)
        check("selected_margin", row.selected_margin, api_res["margin"], is_float=True)
        
        check("decision", row.decision, api_res["frame_decision"])
        
        if errors:
            failures.append({
                "filename": img_path.name,
                "errors": "; ".join(errors)
            })
            
    return len(images), failures

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-dir", type=Path, default=Path(r"F:\PYTORCH_WORKSPACE\disguise-id"))
    parser.add_argument("--gallery-csv", type=Path, default=Path(r"F:\PENELITIAN\DISGUISE-ID\dataset\+ATRIBUT\DPO_SYSTEM_PREPARED\gallery.csv"))
    parser.add_argument("--input-dir", type=Path, default=Path(r"F:\PENELITIAN\DISGUISE-ID\dataset\+ATRIBUT\DPO_SYSTEM_PREPARED\query"))
    parser.add_argument("--api-url", type=str, default="http://localhost:8001/v2/infer-face")
    parser.add_argument("--api-key", type=str, default="test_secret_key")
    args = parser.parse_args()

    # Make output dir
    output_dir = Path("outputs/phase2_parity").resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print("Phase 2 Parity Check")
    print("=" * 60)
    
    try:
        run_stage36_script(args.project_dir, args.gallery_csv, args.input_dir, output_dir)
    except Exception as e:
        print(f"Failed to run baseline: {e}")
        return 1
        
    baseline_csv = output_dir / "decision_results.csv"
    if not baseline_csv.exists():
        print("Baseline CSV not found, something went wrong.")
        return 1
        
    total, failures = compare_results(baseline_csv, args.api_url, args.api_key, args.input_dir, output_dir)
    
    if failures:
        print(f"\nPARITY FAILED: {len(failures)} out of {total} images had mismatches.")
        failures_df = pd.DataFrame(failures)
        failures_path = output_dir / "failures.csv"
        failures_df.to_csv(failures_path, index=False)
        print(f"Details saved to {failures_path}")
        return 1
    else:
        print(f"\nPARITY PASSED: 100% match on all {total} images.")
        
    # generate parity summary
    summary = {
        "parity_images": total,
        "parity_passed": total - len(failures),
        "parity_failed": len(failures)
    }
    with open(output_dir / "parity_summary.json", "w") as f:
        json.dump(summary, f, indent=2)

    return 0

if __name__ == "__main__":
    sys.exit(main())
