import sys
import httpx

def main():
    try:
        # Check if the service is running and healthy
        resp = httpx.get("http://localhost:8001/health", timeout=5.0)
        resp.raise_for_status()
        
        # Check model info
        headers = {"x-api-key": "test_secret_key"}
        resp = httpx.get("http://localhost:8001/v2/model-info", headers=headers, timeout=5.0)
        resp.raise_for_status()
        info = resp.json()
        
        if info.get("gallery_identities", 0) == 0:
            print("PREFLIGHT WARNING: Gallery identities count is 0")
        
        print("Preflight check passed.")
        return 0
    except Exception as e:
        print(f"Preflight check failed: {e}")
        return 1

if __name__ == "__main__":
    sys.exit(main())
