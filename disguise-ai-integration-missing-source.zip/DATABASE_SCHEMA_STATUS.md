# DATABASE SCHEMA STATUS

## 1. Apakah migration 20260714133041 sudah diterapkan?
Ya, berdasarkan direktori `prisma/migrations/`, folder `20260714133041_` ditemukan dan tercatat di migration lock, menandakan migration tersebut telah diterapkan di database eksisting.

## 2. Apakah kolom embedding masih terdapat pada:
- **watchlist_persons**: Ya. Meskipun tidak dideklarasikan sebagai `Unsupported("vector")` secara eksplisit di skema Prisma, anotasinya jelas menyebutkan `// Note: embedding (vector) managed via raw SQL`. Kode raw SQL di `inference.worker.ts` juga mengeksekusi `SELECT ... (embedding <-> $1::vector) FROM watchlist_persons`, membuktikan kolom ini hidup di tabel database.
- **watchlist_photos**: Tidak. Tidak ditemukan kolom atau anotasi embedding pada `watchlist_photos`.
- **detection_events**: Ya. Terdapat anotasi `// embedding stored via raw SQL` di skema, dan `inference.worker.ts` melakukan `UPDATE detection_events SET embedding = ...`.

## 3. Apakah pipeline inference V1 saat ini masih berjalan tanpa error?
Ya. Kode `inference.worker.ts` V1 saat ini intact, terhubung dengan `BullMQ`, dan masih memanggil endpoint `/process-frame` di FastAPI yang menghasilkan 128D vektor L2 (Euclidean). Arsitekturnya sepenuhnya terhubung (mulai dari kamera -> MediaMTX -> Edge -> Express endpoint -> Worker -> ML Service).
